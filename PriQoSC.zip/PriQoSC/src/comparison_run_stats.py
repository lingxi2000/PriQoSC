"""Shared run-level checkpoint and statistics helpers for comparison scripts."""

from __future__ import annotations

import math
import os
import pickle
import statistics
from pathlib import Path
from typing import Any, Callable, Dict, List, Tuple


def atomic_pickle(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as handle:
        pickle.dump(payload, handle, protocol=pickle.HIGHEST_PROTOCOL)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def save_completed_runs(
    path: Path,
    metadata: Dict[str, Any],
    completed_runs: List[Dict[str, Any]],
) -> None:
    atomic_pickle(
        path,
        {
            "metadata": metadata,
            "completed_runs": completed_runs,
        },
    )


def load_completed_runs(
    path: Path,
    metadata: Dict[str, Any],
    restart: bool,
) -> List[Dict[str, Any]]:
    if restart:
        path.unlink(missing_ok=True)
        return []
    if not path.exists():
        return []
    try:
        with path.open("rb") as handle:
            payload = pickle.load(handle)
    except Exception as exc:
        raise RuntimeError(
            f"Cannot read run checkpoint {path}: {exc}. "
            "Use --restart-runs to start the 10 runs again."
        ) from exc
    if payload.get("metadata") != metadata:
        raise RuntimeError(
            f"Run checkpoint configuration does not match: {path}. "
            "Use --restart-runs to start the 10 runs again."
        )
    completed_runs = payload.get("completed_runs")
    if not isinstance(completed_runs, list):
        raise RuntimeError(f"Invalid completed-run checkpoint: {path}")
    return completed_runs


def mean_sample_std(values) -> Tuple[float, float]:
    numeric = [float(value) for value in values]
    if not numeric:
        raise RuntimeError("Cannot summarize zero completed runs.")
    if not all(math.isfinite(value) for value in numeric):
        raise ValueError("Run-level statistic contains a non-finite value.")
    mean_value = float(statistics.fmean(numeric))
    std_value = float(statistics.stdev(numeric)) if len(numeric) > 1 else 0.0
    return mean_value, std_value


def extract_mean_std(
    completed_runs: List[Dict[str, Any]],
    extractor: Callable[[Dict[str, Any]], float],
) -> Tuple[float, float]:
    return mean_sample_std(extractor(run) for run in completed_runs)


def format_mean_std(
    completed_runs: List[Dict[str, Any]],
    extractor: Callable[[Dict[str, Any]], float],
    scale: float = 1.0,
    digits: int = 4,
) -> str:
    mean_value, std_value = extract_mean_std(completed_runs, extractor)
    return (
        f"{scale * mean_value:.{digits}f}"
        f"±{scale * std_value:.{digits}f}"
    )
